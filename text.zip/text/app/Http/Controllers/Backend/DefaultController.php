<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


use App\Product;
use App\Supplier;
use App\Unit;
use App\Category;

use App\Purchase;


class DefaultController extends Controller
{
     public function getCategory(Request $request)
    {
       $supplier_id =$request->supplier_id;
       $allCategoy= Product::select('supplier_id')->where('supplier_id',$supplier_id)
       ->groupBy('supplier_id')->get();
       return response()->json($allCategoy);
    }


}
