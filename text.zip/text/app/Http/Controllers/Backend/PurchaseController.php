<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Product;
use App\Supplier;
use App\Unit;
use App\Category;

use App\Purchase;

class PurchaseController extends Controller
{
   public function view(){
       $allData=Purchase::orderBy('date','desc')->orderBy('id','desc')->get();
       return view('backend.purchase.view-purchase',compact('allData'));
   }

   public function add(){
       $data['suppliers']=Supplier::all();
       $data['units']=unit::all();
       $data['categories']=Category::all();
       return view('backend.purchase.add-purchase',$data);
   }
}
