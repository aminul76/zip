<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   
    
</head>
<body>
    


   <div class="container py-5">
    <form>
        <div class="form-row">
            <div class="col">

                <label>Puchase No</label>
                <input type="text" class="form-control" name="purchase_no" id="purchase_no">
              </div>

             
          <div class="col">
            <label>Supplier name</label>
            <select id="supplier_id" name="suppler_id" class="form-control">

              <option selected>selec Suppler name</option>
              @foreach ($suppliers as $supplier)
                  
            <option value="{{$supplier->id}}">{{$supplier->suppllier_name}}</option>

              @endforeach
             

            </select>
          </div>
          <div class="col">
            <label >Category</label>
            <select id="category_id" name="category_id" class="form-control">
                <option value="">Select Catogory</option>
               
            </select>
          </div>

          <div class="col">
            <label >Poroduct Name</label>
            <select id="product_id" name="product_id" class="form-control">
                <option value="">Select Catogory</option>
               
            </select>
          </div>

        </div>
        <div class="form-group col-md-6">
            <a class="btn btn-primary ">additem</a>
        </div>

      </form>
   


   </div>



   <script type="text/javascript">
    $(function() {
        $(document).on('change', '#suppler_id', function() {
            var supplier_id = $(this).val();
            $.ajax({
                url: "{{route('get-category')}}",
                type: "GET",
                data: {
                    supplier_id: supplier_id
                },
                success: function(data) {
                    var html = '<option value="">Select Category<iption>';
                    $.each(data.function(key.v) {
                        html += '<option value="'+v.category_id+'">'+v.category_id+'</option>';
                    });
                    $(#category_id).html(html);
                }
            })
        });
    })
</script>




<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
</body>
</html>